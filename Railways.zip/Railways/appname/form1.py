from flask import *
app = Flask(_name_)

@app.route("/login")
def login():
	return render_template("login.html")
	
@app.route("/reg")
def reg():
	return render_template("reg.html")

if_name_ == '_main_':
	app.run(debug = True)
